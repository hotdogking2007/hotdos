print("hotdos 0.4b") #부팅 시작
print("made in hotdog, mccake6")
print("language: kor")
print("")
print("github: https://github.com/hotdogking2007/hotdos.git")
print("discord:https://discord.gg/gGpXk6fxBk")
print("")
print("booting ...")
hotdos_date = open("hotdos_date/name.txt", "r",)
hotdos_name = hotdos_date.readline()
hotdos_date.close()
hotdos_date = open("hotdos_date/password.txt")
hotdos_password = hotdos_date.readline()
hotdos_date.close()
print("")
print(hotdos_name, "님 환영합니다.")
print("")
print("명령어나 설치된 프로그램을 모르시겠다면 /help 또는 /program 을 입력해주세요.")
print("")
while True:
    if hotdos_name == "no date": #이름 설정이 안되어 있을때
        print("당신의 이름을 입력해주세요.")
        console = input(">")
        hotdos_date = open("hotdos_date/name.txt", "w",)
        hotdos_date.write(console)
        hotdos_name = hotdos_date
        hotdos_date.close()
        print("이름이 입력 되었습니다.")

    if hotdos_password == "no date": #비밀번호 설정
        print("비밀번호를 입력해 주세요.")
        console = input(">")
        hotdos_password = open("hotdos_date/password.txt", "w",)
        hotdos_password.write(console)
        hotdos_date = hotdos_date
        hotdos_date.close()
        print("비밀번호가 입력 되었습니다.")

    console = input("")
    if console == "/name":
        print("")
        print(hotdos_name)
        print("")

    if console == "/r first":
        hotdos_date = open("hotdos_date/first.txt", "r", encoding='UTF-8')
        while 1 :
            line = hotdos_date.readline()
            if not line:
                break
            
            print(line)
        hotdos_date.close()
    if console == "/w first":
        hotdos_date = open("hotdos_date/first.txt", "w", encoding='UTF-8')
        hotdos_date.write(input("덮어쓸 내용을 적으십시오\n>>>"))
        hotdos_date.close()
        print("save")

    if console == "/newname": #이름변경
        print("새 이름을 입력해주세요.")
        print("이름은 재부팅 후 변경됩니다.")
        console = input(">")
        hotdos_date = open("hotdos_date/name.txt", "w",)
        hotdos_date.write(console)
        hotdos_name = hotdos_date
        hotdos_date.close()
        print("이름을 변경 하였습니다.")
        print("이름은 재부팅 후 적용됩니다.")
        print("")

    if console == "/help": #도움말
        print("")
        print("---명령어---\n/name-내이름\n/r (file(first))\n/file - 파일 보기\n/w (file(first)) - 내용덮어쓰기\n/newname - 이름 변경(재부팅 후 적용)\n/newpassword - 비밀번호 변경\n>>>")
        print("")

    if console == "/newpassword":
        print("새로운 비밀번호를 입력해 주세요.")
        console = input(">")
        hotdos_password = open("hotdos_date/password.txt", "w",)
        hotdos_password.write(console)
        hotdos_date = hotdos_date
        hotdos_date.close()
        print("새로운 비밀번호가 입력 되었습니다 재부팅 후 적용됩니다.")
 
